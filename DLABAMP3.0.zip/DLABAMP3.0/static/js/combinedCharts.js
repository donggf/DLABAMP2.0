// import * as echarts from 'echarts';
// import {
//   TitleComponent,
//   GridComponent,
//   DataZoomComponent,
//   TooltipComponent,
//   LegendComponent
// } from 'echarts/components';
// import { BarChart, PieChart } from 'echarts/charts';
// import { CanvasRenderer } from 'echarts/renderers';
// import { LabelLayout } from 'echarts/features';
//
// // 使用必要的组件和图表类型
// echarts.use([
//   TitleComponent,
//   GridComponent,
//   DataZoomComponent,
//   TooltipComponent,
//   LegendComponent,
//   BarChart,
//   PieChart,
//   CanvasRenderer,
//   LabelLayout
// ]);

// 图表1：Family origin
var chart1 = echarts.init(document.getElementById('chartContainer'));
var option1 = {
  title: {
    //下面 这两个地方可以给echart添加名字
    text: '',
    subtext: ''
  },
  xAxis: {
    data: [
      'A', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'K', 'L', 'M', 'N',
      'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Y'
    ],
    axisLabel: {
      inside: true,
      color: '#fff'
    },
    axisTick: {
      show: false
    },
    axisLine: {
      show: false
    },
    z: 10
  },
  yAxis: {
    axisLine: {
      show: false
    },
    axisTick: {
      show: false
    },
    axisLabel: {
      color: '#999'
    }
  },
  dataZoom: [
    {
      type: 'inside'
    }
  ],
  series: [
    {
      type: 'bar',
      showBackground: true,
      itemStyle: {
        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
          { offset: 0, color: '#83bff6' },
          { offset: 0.5, color: '#188df0' },
          { offset: 1, color: '#188df0' }
        ])
      },
      emphasis: {
        itemStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: '#2378f7' },
            { offset: 0.7, color: '#2378f7' },
            { offset: 1, color: '#83bff6' }
          ])
        }
      },
      data: [
        7.99, 0.83, 5.28, 4.00, 3.08, 9.05, 1.84, 5.56, 7.39, 5.70,
        1.75, 7.13, 4.01, 4.49, 3.07, 6.87, 7.23, 6.53, 2.36, 0.02, 5.83
      ]
    }
  ]
};
chart1.setOption(option1);

// 图表2：Referer of a Website
var chart2 = echarts.init(document.getElementById('chartContainer2'));
var option2 = {
  title: {
    // text: 'Referer of a Website',
    // subtext: 'Fake Data',
    // left: 'center'
  },
  tooltip: {
    trigger: 'item'
  },
  legend: {
    orient: 'vertical',
    left: 'left'
  },
  series: [
    {
      name: 'Access From',
      type: 'pie',
      radius: '50%',
      label: ' ',
      data: [
          { value: 2, name: 'CRISPR-associated endoribonuclease Cas2 prote' },
        { value: 71, name: 'class I bacteriocin' },
        { value: 14, name: 'lipopeptides family' },
        { value: 8, name: 'lantibiotic family' },
        { value: 150, name: 'class II bacteriocin' },
        { value: 5, name: 'staphylococcal hemolytic protein family' },
        { value: 1, name: 'thiocillin family' }
      ],
      emphasis: {
        itemStyle: {
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 0, 0, 0.5)'
        }
      }
    }
  ]
};
chart2.setOption(option2);




