import pymysql
from flask import Flask, request, jsonify, render_template
import joblib
import pandas as pd
from Bio import SeqIO
from io import StringIO

app = Flask(__name__)

# MySQL数据库连接配置
MYSQL_HOST = '127.0.0.1'
MYSQL_USER = 'root'
MYSQL_PASSWORD = '123456'  # 请替换为您的实际密码
MYSQL_DB = 'dlabamp'

def connect_to_mysql():
    return pymysql.connect(host=MYSQL_HOST,
                           user=MYSQL_USER,
                           password=MYSQL_PASSWORD,
                           database=MYSQL_DB,
                           charset='utf8mb4',
                           cursorclass=pymysql.cursors.DictCursor)

@app.route('/')
def index():
    try:
        # 连接到MySQL数据库
        connection = connect_to_mysql()

        # 获取页码参数，如果没有则默认为第一页
        page = int(request.args.get('page', 1))

        with connection.cursor() as cursor:
            # 计算偏移量
            offset = (page - 1) * 7
            # 执行查询，选择所需的字段，并进行分页
            cursor.execute('SELECT LAD_ID, Sequence_Length,Family, Gene, Source, Activity FROM lad LIMIT %s, %s', (offset, 7))
            data = cursor.fetchall()

            # 获取总数据条数
            cursor.execute('SELECT COUNT(*) as total FROM lad')
            total_data = cursor.fetchone()['total']

        # 计算总页数
        total_pages = (total_data + 6) // 7  # 向上取整

        # 计算需要显示的页码范围
        page_range = range(max(1, page - 2), min(total_pages + 1, page + 3))

    finally:
        connection.close()

    return render_template('browse.html', data=data, page=page, total_pages=total_pages, page_range=page_range)

@app.route('/show_more_data')
def show_more_data():
    lad_id = request.args.get('lad_id')

    # 连接到MySQL数据库
    connection = connect_to_mysql()

    try:
        with connection.cursor() as cursor:
            # 执行查询，根据 LAD_ID 获取完整的词条数据
            cursor.execute('SELECT * FROM lad WHERE LAD_ID = %s', (lad_id,))
            full_data = cursor.fetchone()
    finally:
        connection.close()

    # 返回查询到的完整数据
    return jsonify(full_data)

@app.route('/home',methods=['GET'],endpoint='home_index')
def index():
    return render_template("index.html")

@app.route('/download',methods=['GET'],endpoint='download_index')
def downloaad():
    return render_template("download.html")

@app.route('/statistics',endpoint='statistics_index')
def statistics():
    return render_template('statistics.html')

@app.route('/show_more')
def show_more():
    lad_id = request.args.get('lad_id')

    # 连接到MySQL数据库
    connection = connect_to_mysql()

    try:
        with connection.cursor() as cursor:
            # 执行查询，根据 LAD_ID 获取完整的词条数据
            cursor.execute('SELECT * FROM lad WHERE LAD_ID = %s', (lad_id,))
            full_data = cursor.fetchone()
    finally:
        connection.close()

    # 返回查询到的完整数据，渲染新的 HTML 页面来显示
    return render_template('show_more.html', full_data=full_data)

# _______________________________________________________
def aac(sequence):
    amino_acids = 'ACDEFGHIKLMNPQRSTVWY'
    aac_vector = [sequence.count(aa) / len(sequence) for aa in amino_acids]
    return aac_vector


# 加载模型
model_path = 'model/active.joblib'
rf_model = joblib.load(model_path)

# 标签描述映射
label_descriptions = {
    1: "Anti-Gram+ & Gram-",
    2: "Anti-Gram+",
    3: "Anti-Gram-",
    4: "Anticancer",
    5: "MRSA",
    6: "Antifungal"
}


@app.route('/model/antimicrobial',endpoint='active_index')
def index():
    return render_template('active.html')

@app.route('/predict1', methods=['POST'])
def predict():
    data = request.form.get('sequenceInput')
    predictions = []

    if 'fileInput' in request.files and request.files['fileInput'].filename:
        file = request.files['fileInput']
        fasta_content = file.read().decode('utf-8')
        fasta_sequences = list(SeqIO.parse(StringIO(fasta_content), "fasta"))

        for seq_record in fasta_sequences:
            sequence = str(seq_record.seq)
            user_feature = pd.DataFrame([aac(sequence)])
            prediction, result = make_prediction(user_feature)
            predictions.append(f"Sequence {seq_record.id}: {result}")
    elif data:
        user_feature = pd.DataFrame([aac(data)])
        prediction, result = make_prediction(user_feature)
        predictions.append(f"Sequence: {result}")

    return jsonify(result='\n'.join(predictions))


def make_prediction(user_feature):
    prediction = rf_model.predict(user_feature)
    label = prediction[0]
    description = label_descriptions.get(label, "Unknown")

    return prediction, description
# _______________________________________________________
# _______________________________________________________
def aac(sequence):
    amino_acids = 'ACDEFGHIKLMNPQRSTVWY'
    aac_vector = [sequence.count(aa) / len(sequence) for aa in amino_acids]
    return aac_vector


# 加载模型
model_path_1 = 'model/family1.joblib'
model_path_2 = 'model/rf_model_multiclass.joblib'
rf_model_1 = joblib.load(model_path_1)
rf_model_2 = joblib.load(model_path_2)


@app.route('/model/family',endpoint='family_index')
def index():
    return render_template('family.html')


@app.route('/predict2', methods=['POST'],endpoint='predict2_index')
def predict():
    data = request.form.get('sequenceInput')
    predictions = []

    if 'fileInput' in request.files and request.files['fileInput'].filename:
        file = request.files['fileInput']
        fasta_content = file.read().decode('utf-8')
        fasta_sequences = list(SeqIO.parse(StringIO(fasta_content), "fasta"))

        for seq_record in fasta_sequences:
            sequence = str(seq_record.seq)
            user_feature = pd.DataFrame([aac(sequence)])
            prediction_1, result = make_prediction(user_feature)
            predictions.append(f"Sequence {seq_record.id}: {result}")
    elif data:
        user_feature = pd.DataFrame([aac(data)])
        prediction_1, result = make_prediction(user_feature)
        predictions.append(f"Sequence: {result}")

    return jsonify(result='\n'.join(predictions))


def make_prediction(user_feature):
    # 使用第一个模型进行预测
    prediction_1 = rf_model_1.predict(user_feature)
    prediction_proba_1 = rf_model_1.predict_proba(user_feature)

    label_1 = prediction_1[0]
    probability_1 = prediction_proba_1[0][rf_model_1.classes_.tolist().index(label_1)]

    result = ""
    if label_1 == 0:
        result = 'Belongs to Class II bacteriocin'
        prediction_2 = rf_model_2.predict(user_feature)
        prediction_proba_2 = rf_model_2.predict_proba(user_feature)

        label_2 = prediction_2[0]
        probability_2 = prediction_proba_2[0][rf_model_2.classes_.tolist().index(label_2)]

        class_ii_labels = {
            'a': 'Belongs to the class IIa bacteriocin',
            'b': 'Belongs to the class IIb bacteriocin',
            'c': 'Belongs to the class IIc bacteriocin',
            'd': 'Belongs to the class IId bacteriocin'
        }

        result = class_ii_labels.get(label_2, 'Unknown class II bacteriocin')
    else:
        result = 'Belongs to Class I bacteriocin'

    return prediction_1, result

# _______________________________________________________

if __name__ == '__main__':
    app.run(debug=True, port=8086, host='0.0.0.0')
